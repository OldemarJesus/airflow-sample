from office365.runtime.client_value import ClientValue


class IntuneBrand(ClientValue):
    """intuneBrand contains data which is used in customizing the appearance of the Company Portal applications as
    well as the end user web portal."""
