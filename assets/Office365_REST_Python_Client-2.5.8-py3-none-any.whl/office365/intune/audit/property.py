from office365.runtime.client_value import ClientValue


class AuditProperty(ClientValue):
    """A class containing the properties for Audit Property."""
