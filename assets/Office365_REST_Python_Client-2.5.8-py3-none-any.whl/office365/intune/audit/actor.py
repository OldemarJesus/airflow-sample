from office365.runtime.client_value import ClientValue


class AuditActor(ClientValue):
    """A class containing the properties for Audit Actor."""
