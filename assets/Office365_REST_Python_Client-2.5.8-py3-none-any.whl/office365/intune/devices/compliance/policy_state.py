from office365.entity import Entity


class DeviceCompliancePolicyState(Entity):
    """Device Compliance Policy State for a given device"""
