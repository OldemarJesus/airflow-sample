from office365.entity import Entity


class ServiceHealth(Entity):
    """Represents the health information of a service subscribed by a tenant."""
