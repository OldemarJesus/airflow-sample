from office365.entity import Entity


class SimulationAutomationRun(Entity):
    """Represents a run of an attack simulation automation on a tenant."""
