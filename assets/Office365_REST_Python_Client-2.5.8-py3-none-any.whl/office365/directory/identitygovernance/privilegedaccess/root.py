from office365.entity import Entity


class PrivilegedAccessRoot(Entity):
    """Represents the entry point for resources related to Privileged Identity Management (PIM)."""
