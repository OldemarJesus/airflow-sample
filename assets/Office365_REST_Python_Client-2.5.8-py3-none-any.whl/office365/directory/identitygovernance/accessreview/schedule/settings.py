from office365.runtime.client_value import ClientValue


class AccessReviewScheduleSettings(ClientValue):
    """The accessReviewScheduleSettings defines the settings of an accessReviewScheduleDefinition."""
