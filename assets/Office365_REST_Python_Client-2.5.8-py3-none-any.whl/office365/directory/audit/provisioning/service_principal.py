from office365.directory.permissions.identity import Identity


class ProvisioningServicePrincipal(Identity):
    """Represents the service principal used for provisioning."""
