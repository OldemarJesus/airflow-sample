class ProvisioningAction:
    """"""
