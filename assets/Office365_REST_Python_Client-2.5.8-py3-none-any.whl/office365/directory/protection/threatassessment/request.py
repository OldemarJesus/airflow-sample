from office365.entity import Entity


class ThreatAssessmentRequest(Entity):
    """An abstract resource type used to represent a threat assessment request item."""
