from office365.runtime.client_value import ClientValue


class DomainState(ClientValue):
    """Represents the status of asynchronous operations scheduled on a domain."""
