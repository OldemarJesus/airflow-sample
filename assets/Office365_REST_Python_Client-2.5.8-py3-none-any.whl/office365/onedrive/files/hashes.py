from office365.runtime.client_value import ClientValue


class Hashes(ClientValue):
    """The Hashes resource groups available hashes into a single structure for an item."""
