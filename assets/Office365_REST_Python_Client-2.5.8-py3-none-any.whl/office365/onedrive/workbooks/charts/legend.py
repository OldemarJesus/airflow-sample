from office365.entity import Entity


class WorkbookChartLegend(Entity):
    """Represents the legend in a chart."""

    pass
