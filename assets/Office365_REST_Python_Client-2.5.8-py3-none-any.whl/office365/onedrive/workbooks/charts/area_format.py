from office365.entity import Entity


class WorkbookChartAreaFormat(Entity):
    """Encapsulates the format properties for the overall chart area."""

    pass
