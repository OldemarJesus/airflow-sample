from office365.entity import Entity


class WorkbookFormatProtection(Entity):
    """Represents the format protection of a range object."""
