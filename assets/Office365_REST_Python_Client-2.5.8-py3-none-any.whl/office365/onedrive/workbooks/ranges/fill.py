from office365.entity import Entity


class WorkbookRangeFill(Entity):
    """Represents the background of a range object."""
