class SensitivityLabelAssignmentMethod:
    standard = "standard"
    """The assignment method for the label is standard."""
