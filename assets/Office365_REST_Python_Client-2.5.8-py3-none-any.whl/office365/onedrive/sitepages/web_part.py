from office365.entity import Entity


class WebPart(Entity):
    """Represents a specific web part instance on a SharePoint page."""
