from office365.communications.operations.comms import CommsOperation


class UnmuteParticipantOperation(CommsOperation):
    """Describes the response format of a call participant unmute operation."""
