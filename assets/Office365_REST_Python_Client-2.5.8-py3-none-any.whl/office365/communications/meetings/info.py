from office365.runtime.client_value import ClientValue


class MeetingInfo(ClientValue):
    """An abstract class that contains meeting-specific information."""
