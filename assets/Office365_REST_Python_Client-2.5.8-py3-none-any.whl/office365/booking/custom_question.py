from office365.entity import Entity


class BookingCustomQuestion(Entity):
    """Represents a custom question for a bookingBusiness."""
