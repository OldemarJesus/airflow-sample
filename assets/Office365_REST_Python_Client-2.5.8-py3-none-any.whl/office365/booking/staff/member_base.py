from office365.entity import Entity


class BookingStaffMemberBase(Entity):
    """Base type of bookingStaffMember."""
